import argparse
import json
from pathlib import Path

from motion_server_reference_client import MotionServerClient

from motion_server_gamepad.config import load_config
from motion_server_gamepad.controller import PendantController
from motion_server_gamepad.gui import show
from motion_server_gamepad.input import PygameJoystickAdapter, list_pygame_devices


def main():
    parser = argparse.ArgumentParser(description="Motion Server Windows gamepad pendant")
    parser.add_argument(
        "--config",
        type=Path,
        default=Path(__file__).parents[1] / "config.json",
    )
    parser.add_argument("--list-devices", action="store_true")
    args = parser.parse_args()
    if args.list_devices:
        print(json.dumps(list_pygame_devices(), indent=2, ensure_ascii=False))
        return 0
    config = load_config(args.config)
    client = MotionServerClient(
        config.host,
        config.port,
        request_timeout=config.request_timeout,
    )
    adapter = PygameJoystickAdapter(config)
    show(PendantController(config, client, adapter))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
