from dataclasses import dataclass
import json
import math
from pathlib import Path


ROLES = ("x", "y", "z", "rotation")
STICKS = ("left_x", "left_y", "right_x", "right_y")
BUTTONS = (
    "l1",
    "circle",
    "square",
    "triangle",
    "options",
    "create",
    "touchpad",
)


@dataclass(frozen=True)
class GamepadConfig:
    host: str
    port: int
    request_timeout: float
    device_name: str
    device_guid: str
    axes: dict[str, int]
    max_velocity: dict[str, float]
    invert: dict[str, bool]
    stick_axes: dict[str, int]
    buttons: dict[str, int]
    hat: int
    deadzone: float
    update_period: float
    speed_scales: tuple[float, ...]
    speed_scale_default: float


def load_config(path):
    source = Path(path)
    try:
        value = json.loads(source.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"Cannot load gamepad config: {exc}") from exc
    if not isinstance(value, dict):
        raise ValueError("Gamepad config root must be an object")

    server = required_object(value, "server")
    device = required_object(value, "device")
    mapping = required_object(device, "mapping")
    axes = integer_map(required_object(value, "axes"), ROLES, "axes")
    if len(set(axes.values())) != len(axes):
        raise ValueError("Axis role indices must be unique")
    maximums = number_map(required_object(value, "max_velocity"), ROLES, "max_velocity")
    if any(number <= 0.0 for number in maximums.values()):
        raise ValueError("max_velocity values must be > 0")
    invert = boolean_map(required_object(value, "invert"), ROLES, "invert")
    stick_axes = integer_map(required_object(mapping, "axes"), STICKS, "mapping.axes")
    buttons = integer_map(required_object(mapping, "buttons"), BUTTONS, "mapping.buttons")
    hat = strict_int(mapping.get("hat"), "mapping.hat", minimum=0)
    deadzone = finite_number(value.get("deadzone"), "deadzone")
    if not 0.0 <= deadzone < 1.0:
        raise ValueError("deadzone must satisfy 0 <= value < 1")
    update_period_ms = finite_number(value.get("update_period_ms"), "update_period_ms")
    if update_period_ms <= 0.0:
        raise ValueError("update_period_ms must be > 0")
    raw_scales = value.get("speed_scales")
    if not isinstance(raw_scales, list) or not raw_scales:
        raise ValueError("speed_scales must be a non-empty array")
    scales = tuple(finite_number(item, "speed_scales") for item in raw_scales)
    if any(not 0.0 < item <= 1.0 for item in scales) or list(scales) != sorted(set(scales)):
        raise ValueError("speed_scales must be unique ascending values in (0, 1]")
    default_scale = finite_number(value.get("speed_scale_default"), "speed_scale_default")
    if default_scale not in scales:
        raise ValueError("speed_scale_default must be present in speed_scales")

    host = required_text(server, "host")
    port = strict_int(server.get("port"), "server.port", minimum=1, maximum=65535)
    request_timeout = finite_number(server.get("request_timeout", 3.0), "server.request_timeout")
    if request_timeout <= 0.0:
        raise ValueError("server.request_timeout must be > 0")

    return GamepadConfig(
        host=host,
        port=port,
        request_timeout=request_timeout,
        device_name=required_text(device, "name"),
        device_guid=required_text(device, "guid").lower(),
        axes=axes,
        max_velocity=maximums,
        invert=invert,
        stick_axes=stick_axes,
        buttons=buttons,
        hat=hat,
        deadzone=deadzone,
        update_period=update_period_ms / 1000.0,
        speed_scales=scales,
        speed_scale_default=default_scale,
    )


def required_object(value, key):
    result = value.get(key)
    if not isinstance(result, dict):
        raise ValueError(f"{key} must be an object")
    return result


def required_text(value, key):
    result = value.get(key)
    if not isinstance(result, str) or not result.strip():
        raise ValueError(f"{key} must be a non-empty string")
    return result.strip()


def strict_int(value, field, *, minimum=None, maximum=None):
    if not isinstance(value, int) or isinstance(value, bool):
        raise ValueError(f"{field} must be an integer")
    if minimum is not None and value < minimum:
        raise ValueError(f"{field} must be >= {minimum}")
    if maximum is not None and value > maximum:
        raise ValueError(f"{field} must be <= {maximum}")
    return value


def finite_number(value, field):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{field} must be a JSON number")
    result = float(value)
    if not math.isfinite(result):
        raise ValueError(f"{field} must be finite")
    return result


def integer_map(value, keys, field):
    if set(value) != set(keys):
        raise ValueError(f"{field} must contain exactly {list(keys)}")
    return {key: strict_int(value[key], f"{field}.{key}", minimum=0) for key in keys}


def number_map(value, keys, field):
    if set(value) != set(keys):
        raise ValueError(f"{field} must contain exactly {list(keys)}")
    return {key: finite_number(value[key], f"{field}.{key}") for key in keys}


def boolean_map(value, keys, field):
    if set(value) != set(keys) or any(type(value[key]) is not bool for key in keys):
        raise ValueError(f"{field} must contain exactly Boolean values for {list(keys)}")
    return dict(value)
