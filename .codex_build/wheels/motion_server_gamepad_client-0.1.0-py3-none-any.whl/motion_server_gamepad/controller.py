from dataclasses import dataclass
import queue
import threading
import time


ROLE_STICKS = {
    "x": "left_x",
    "y": "left_y",
    "z": "right_y",
    "rotation": "right_x",
}
OPERATION_ENABLED_MASK = 0x006F
OPERATION_ENABLED_STATUS = 0x0027
MOVING_BIT = 1 << 8
FAULT_BIT = 1 << 3


@dataclass(frozen=True)
class PendantStatus:
    state: str
    mode: str
    selected_axis: int
    speed_scale: float
    authority: str
    last_error: str
    last_notice: str


class PendantController:
    def __init__(self, config, client, input_adapter):
        self.config = config
        self.client = client
        self.input = input_adapter
        self.state = "Disconnected"
        self.mode = "multi"
        self.selected_axis = config.axes["x"]
        self.scale_index = config.speed_scales.index(config.speed_scale_default)
        self.feedback = {}
        self.axis_contract = None
        self.last_error = ""
        self.last_notice = ""
        self._previous_buttons = {}
        self._previous_hat = (0, 0)
        self._l1_released_since_connect = False
        self._neutral_stop_sent = False
        self._stop = threading.Event()
        self._thread = None
        self._lock = threading.RLock()

    def start(self):
        self.input.start()
        self.client.start()
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="gamepad-control", daemon=True)
        self._thread.start()

    def stop(self):
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=self.config.request_timeout + 1.0)
        self.input.stop()
        self.client.stop()

    def update_feedback(self, message):
        with self._lock:
            self.feedback = dict(message)

    def status(self):
        with self._lock:
            authority = self.feedback.get("command_authority", {})
            owner = authority.get("owner")
            authority_text = "Owned" if authority.get("owned_by_this_client") else (
                "Available" if authority.get("available") else f"Owner {owner}"
            )
            return PendantStatus(
                state=self.state,
                mode=self.mode,
                selected_axis=self.selected_axis,
                speed_scale=self.config.speed_scales[self.scale_index],
                authority=authority_text,
                last_error=self.last_error,
                last_notice=self.last_notice,
            )

    def tick(self, snapshot=None):
        snapshot = snapshot or self.input.snapshot()
        with self._lock:
            if not self.client.is_connected:
                self._set_disarmed("Disconnected")
                self._remember_inputs(snapshot)
                return
            if self.state == "Disconnected":
                self.state = "Disarmed"
                self._l1_released_since_connect = False
                self.axis_contract = None

            if not snapshot.connected:
                self.last_error = snapshot.error or "Gamepad is not connected"
                self._remember_inputs(snapshot)
                return

            neutral = sticks_neutral(snapshot.sticks, self.config.deadzone)
            l1 = bool(snapshot.buttons.get("l1", False))
            if not l1 and neutral:
                self._l1_released_since_connect = True

            self._handle_edges(snapshot, neutral)
            if self.state == "Armed":
                if not l1:
                    self._disable_mapped("L1 released")
                elif not self._armed_feedback_is_safe():
                    self._disable_mapped("Authority, Axis, or server state was lost")
                elif neutral:
                    if not self._neutral_stop_sent:
                        if self._request(self._axes_message("stop")) is None:
                            self._disable_mapped("Stop failed")
                        else:
                            self._neutral_stop_sent = True
                else:
                    self._neutral_stop_sent = False
                    if self._request(self._velocity_message(snapshot)) is None:
                        self._disable_mapped("Velocity command failed")
            elif self.state == "Arming":
                if not l1:
                    self._disable_mapped("L1 released while arming")
                elif self._mapped_axes_enabled():
                    self.state = "Armed"
                    self.last_notice = "Armed"

            self._remember_inputs(snapshot)

    def _run(self):
        next_tick = time.monotonic()
        while not self._stop.is_set():
            self._drain_feedback()
            self.tick()
            next_tick += self.config.update_period
            delay = next_tick - time.monotonic()
            if delay <= 0.0:
                next_tick = time.monotonic()
                continue
            self._stop.wait(delay)

    def _drain_feedback(self):
        while True:
            try:
                message = self.client.get_feedback(timeout=0.0)
            except queue.Empty:
                return
            self.update_feedback(message)

    def _handle_edges(self, snapshot, neutral):
        rising = {
            name
            for name, pressed in snapshot.buttons.items()
            if pressed and not self._previous_buttons.get(name, False)
        }
        l1_rising = "l1" in rising
        if "options" in rising:
            self._toggle_authority()
            return
        if "circle" in rising:
            self._disable_mapped("Circle pressed")
        elif "square" in rising:
            self._request(self._axes_message("fault_reset"))
        elif "triangle" in rising:
            self._request(self._axes_message("stop"))
        elif "create" in rising:
            self._request({"cmd": "system/axes/stop", "axes": self._all_axes()})
        hat = snapshot.hat
        if hat != self._previous_hat:
            if hat[1] > 0:
                self.scale_index = min(self.scale_index + 1, len(self.config.speed_scales) - 1)
            elif hat[1] < 0:
                self.scale_index = max(self.scale_index - 1, 0)
        if self.state in {"Arming", "Armed", "Releasing"}:
            return
        if "touchpad" in rising:
            if self._transition_allowed(neutral):
                self.mode = "single" if self.mode == "multi" else "multi"
                self.last_notice = f"Mode changed to {self.mode}"
            else:
                self.last_notice = "Mode change rejected: require Disarmed, neutral, Standstill"
        if hat != self._previous_hat:
            if self.mode == "single" and hat[0] != 0:
                if self._transition_allowed(neutral):
                    self._select_axis(hat[0])
                else:
                    self.last_notice = "Axis change rejected: require Disarmed, neutral, Standstill"
        if l1_rising:
            self._arm(neutral)

    def _arm(self, neutral):
        if not self._l1_released_since_connect:
            self.last_notice = "Arm rejected: release L1 at neutral after connection"
            return
        if not self._owns_authority() or not neutral or not self._all_axes_standstill():
            self.last_notice = "Arm rejected: require authority, neutral, all-Axis Standstill"
            return
        if not self._validate_axis_contract():
            return
        self.state = "Arming"
        if self._request(self._axes_message("enable")) is None:
            self._disable_mapped("Enable failed")

    def _toggle_authority(self):
        if self._owns_authority():
            self.state = "Releasing"
            response = self._request({"cmd": "system/authority/release"})
            self.state = "Disarmed"
            if response is None:
                self.last_error = "Authority release failed"
        elif self.feedback.get("command_authority", {}).get("available", False):
            self._request({"cmd": "system/authority/request"})

    def _disable_mapped(self, reason):
        self.state = "Disarmed"
        self._neutral_stop_sent = False
        if self.client.is_connected and self._owns_authority():
            self._request(self._axes_message("disable"))
        self.last_notice = reason

    def _request(self, message):
        try:
            response = self.client.request(message, timeout=self.config.request_timeout)
        except Exception as exc:
            self.last_error = str(exc)
            return None
        if response.get("result") != "success":
            failure = response.get("failure", {})
            self.last_error = f"{failure.get('code', 'FAILED')}: {failure.get('message', '')}"
            return None
        self.last_error = ""
        return response

    def _axes_message(self, action):
        axes = self._mapped_axes()
        command = "system/axis" if len(axes) == 1 else "system/axes"
        message = {"cmd": f"{command}/{action}"}
        message["axis" if len(axes) == 1 else "axes"] = axes[0] if len(axes) == 1 else axes
        return message

    def _velocity_message(self, snapshot):
        axes = self._mapped_axes()
        if self.mode == "single":
            role = self._role_for_axis(self.selected_axis)
            velocity = self._role_velocity(role, snapshot.sticks.get("left_y", 0.0))
            return {"cmd": "system/axis/move_vel", "axis": axes[0], "velocity": velocity}
        velocities = [
            self._role_velocity(role, snapshot.sticks.get(ROLE_STICKS[role], 0.0))
            for role in self.config.axes
        ]
        return {"cmd": "system/axes/move_vel", "axes": axes, "velocities": velocities}

    def _role_velocity(self, role, raw_value):
        value = scaled_deadzone(raw_value, self.config.deadzone)
        if self.config.invert[role]:
            value = -value
        maximum = self.config.max_velocity[role]
        scale = self.config.speed_scales[self.scale_index]
        return max(-maximum, min(maximum, value * maximum * scale))

    def _mapped_axes(self):
        return [self.selected_axis] if self.mode == "single" else list(self.config.axes.values())

    def _all_axes(self):
        return list(range(len(self.feedback.get("statuswords", []))))

    def _select_axis(self, direction):
        axes = list(self.config.axes.values())
        index = axes.index(self.selected_axis)
        self.selected_axis = axes[(index + (1 if direction > 0 else -1)) % len(axes)]
        self.last_notice = f"Selected Axis {self.selected_axis}"

    def _role_for_axis(self, axis_index):
        return next(role for role, value in self.config.axes.items() if value == axis_index)

    def _transition_allowed(self, neutral):
        return self.state == "Disarmed" and neutral and self._all_axes_standstill()

    def _owns_authority(self):
        return bool(self.feedback.get("command_authority", {}).get("owned_by_this_client"))

    def _all_axes_standstill(self):
        statuswords = self.feedback.get("statuswords", [])
        return bool(statuswords) and all(not int(value) & MOVING_BIT for value in statuswords)

    def _mapped_axes_enabled(self):
        statuswords = self.feedback.get("statuswords", [])
        return all(
            axis < len(statuswords)
            and int(statuswords[axis]) & OPERATION_ENABLED_MASK == OPERATION_ENABLED_STATUS
            for axis in self._mapped_axes()
        )

    def _armed_feedback_is_safe(self):
        health = self.feedback.get("server_health", {})
        statuswords = self.feedback.get("statuswords", [])
        return (
            self._owns_authority()
            and bool(self.feedback.get("process_data_valid", False))
            and health.get("runtime_state", "normal") == "normal"
            and self._mapped_axes_enabled()
            and all(not int(statuswords[axis]) & FAULT_BIT for axis in self._mapped_axes())
        )

    def _validate_axis_contract(self):
        if self.axis_contract is None:
            response = self._request({"cmd": "system/axes/status"})
            if response is None:
                return False
            self.axis_contract = response.get("data", {})
        metadata = self.axis_contract.get("axis_metadata", [])
        limits = self.axis_contract.get("motion_limits", [])
        axis_count = len(self.feedback.get("statuswords", []))
        for role, axis_index in self.config.axes.items():
            if axis_index >= axis_count:
                self.last_error = f"Configured {role} Axis {axis_index} is outside server topology"
                return False
            expected = "rotary" if role == "rotation" else "linear"
            kind = metadata[axis_index].get("motion_kind") if axis_index < len(metadata) else None
            if kind != expected:
                self.last_error = f"Configured {role} requires server Axis kind {expected}"
                return False
            limit_index = axis_index * 4
            if limit_index >= len(limits) or self.config.max_velocity[role] > float(limits[limit_index]):
                self.last_error = f"Configured {role} max_velocity exceeds server motion limit"
                return False
        return True

    def _set_disarmed(self, state):
        self.state = state
        self._neutral_stop_sent = False

    def _remember_inputs(self, snapshot):
        self._previous_buttons = dict(snapshot.buttons)
        self._previous_hat = tuple(snapshot.hat)


def scaled_deadzone(value, deadzone):
    value = max(-1.0, min(1.0, float(value)))
    magnitude = abs(value)
    if magnitude <= deadzone:
        return 0.0
    scaled = (magnitude - deadzone) / (1.0 - deadzone)
    return scaled if value > 0.0 else -scaled


def sticks_neutral(sticks, deadzone):
    return all(abs(float(sticks.get(name, 0.0))) <= deadzone for name in ROLE_STICKS.values())
